module.exports = require("@discourse/lint-configs/template-lint");
