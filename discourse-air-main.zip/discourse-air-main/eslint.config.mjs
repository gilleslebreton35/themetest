import DiscourseRecommendedTheme from "@discourse/lint-configs/eslint-theme";

export default [...DiscourseRecommendedTheme];
