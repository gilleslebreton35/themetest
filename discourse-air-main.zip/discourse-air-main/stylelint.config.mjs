export default {
  extends: ["@discourse/lint-configs/stylelint"],
};
